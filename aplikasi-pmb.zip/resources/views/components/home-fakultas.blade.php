<div>
    <div class="container">

        <div class="section-title">
          <h2>Fakultas</h2>
          <p>Universitas Dayanu Ikhsanuddin terdiri dari berbagai macam pilihan Fakultas yang semua nya telah terakreditasi dengan baik.</p>
        </div>

        <div class="row">

            @foreach ($prodi as $item)
            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-heartbeat"></i></div>
                <h4><a href="">{{ $item->prodi_nama }}</a></h4>
                <p>Voluptatum deleniti atque corrupti quos dolores et quas molesti excepturi</p>
                </div>
            </div>
            @endforeach

            {{-- <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-pills"></i></div>
                <h4><a href="">Sed ut perspiciatis</a></h4>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-hospital-user"></i></div>
                <h4><a href="">Magni Dolores</a></h4>
                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-dna"></i></div>
                <h4><a href="">Nemo Enim</a></h4>
                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-wheelchair"></i></div>
                <h4><a href="">Dele cardo</a></h4>
                <p>Quis consequatur saepe eligendi voluptatem consequatur dolor consequuntur</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-notes-medical"></i></div>
                <h4><a href="">Divera don</a></h4>
                <p>Modi nostrum vel laborum. Porro fugit error sit minus sapiente sit aspernatur</p>
                </div>
            </div> --}}

        </div>

      </div>
</div>
