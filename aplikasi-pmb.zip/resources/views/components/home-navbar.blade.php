<div>
    <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="{{ route('home') }}">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#about">Informasi</a></li>
          <li><a class="nav-link scrollto" href="{{ route('home-pendaftaran') }}">Pendaftaran</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
</div>
