<div>

    <section class="section">
        <div class="section-header">
          <h1>{{ $contentheader }}</h1>
        </div>

        <div class="section-body">
            <div class="card">
                <div class="card-body">
                    <h1>Index Page</h1>
                </div>
            </div>
        </div>
    </section>

</div>
