<div>

    <section class="section">
        <div class="section-header">
          <h1>{{ $contentheader }}</h1>
        </div>

        <div class="section-body">
            <div class="card">
                <div class="card-body">
                    <h1>PROFILE Page</h1>
                    <p>
                        PRFILE
                    </p>
                </div>
            </div>
        </div>

      </section>
</div>
