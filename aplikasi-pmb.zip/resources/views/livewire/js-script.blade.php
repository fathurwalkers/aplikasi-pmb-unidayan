<div>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable();
        });
    </script>
</div>
