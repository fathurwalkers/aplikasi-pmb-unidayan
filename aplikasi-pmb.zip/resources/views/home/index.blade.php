@extends('layouts.home-layout')

@section('title', 'Beranda')

@section('header-content')
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center">
        <div class="container">
            <h1>Website Pendaftaraan Mahasiswa Baru</h1>
            <h2>Universitas Dayanu Ikhsanuddin</h2>
            <a href="{{ route('home-pendaftaran') }}" class="btn-get-started scrollto">Mulai Pendaftaran</a>
            <div class="row my-3">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    @if (session('status'))
                        <div class="alert alert-info">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
    <!-- End Hero -->
@endsection

@section('main-content')
    <!-- ======= Why Us Section ======= -->
    {{-- <x-home-why-us /> --}}
    <!-- End Why Us Section -->
    <!-- ======= About Section ======= -->
    {{-- <x-home-about-us /> --}}
    <!-- End About Section -->
    <!-- ======= Counts Section ======= -->
    <x-home-counts />
    <!-- End Counts Section -->
    <!-- ======= Services Section ======= -->
    {{-- <section id="services" class="services">
        <x-home-fakultas :prodi='$prodi' />
    </section> --}}
    <!-- End Services Section -->
    <!-- ======= Appointment Section ======= -->
    {{-- <section id="appointment" class="appointment section-bg">
    <div class="container">
        <div class="section-title">
        <h2>Make an Appointment</h2>
        <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>
        <form action="forms/appointment.php" method="post" role="form" class="php-email-form">
        <div class="row">
            <div class="col-md-4 form-group">
            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
            <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email">
            <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
            <input type="tel" class="form-control" name="phone" id="phone" placeholder="Your Phone" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
            <div class="validate"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 form-group mt-3">
            <input type="datetime" name="date" class="form-control datepicker" id="date" placeholder="Appointment Date" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
            <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3">
            <select name="department" id="department" class="form-select">
                <option value="">Select Department</option>
                <option value="Department 1">Department 1</option>
                <option value="Department 2">Department 2</option>
                <option value="Department 3">Department 3</option>
            </select>
            <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3">
            <select name="doctor" id="doctor" class="form-select">
                <option value="">Select Doctor</option>
                <option value="Doctor 1">Doctor 1</option>
                <option value="Doctor 2">Doctor 2</option>
                <option value="Doctor 3">Doctor 3</option>
            </select>
            <div class="validate"></div>
            </div>
        </div>
        <div class="form-group mt-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Message (Optional)"></textarea>
            <div class="validate"></div>
        </div>
        <div class="mb-3">
            <div class="loading">Loading</div>
            <div class="error-message"></div>
            <div class="sent-message">Your appointment request has been sent successfully. Thank you!</div>
        </div>
        <div class="text-center"><button type="submit">Make an Appointment</button></div>
        </form>
    </div>
    </section> --}}
    <!-- End Appointment Section -->
    <!-- ======= Departments Section ======= -->
    {{-- <section id="departments" class="departments">
    <div class="container">
        <div class="section-title">
        <h2>Departments</h2>
        <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>
        <div class="row gy-4">
        <div class="col-lg-3">
            <ul class="nav nav-tabs flex-column">
            <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">Cardiology</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-2">Neurology</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-3">Hepatology</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-4">Pediatrics</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-5">Eye Care</a>
            </li>
            </ul>
        </div>
        <div class="col-lg-9">
            <div class="tab-content">
            <div class="tab-pane active show" id="tab-1">
                <div class="row gy-4">
                <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Cardiology</h3>
                    <p class="fst-italic">Qui laudantium consequatur laborum sit qui ad sapiente dila parde sonata raqer a videna mareta paulona marka</p>
                    <p>Et nobis maiores eius. Voluptatibus ut enim blanditiis atque harum sint. Laborum eos ipsum ipsa odit magni. Incidunt hic ut molestiae aut qui. Est repellat minima eveniet eius et quis magni nihil. Consequatur dolorem quaerat quos qui similique accusamus nostrum rem vero</p>
                </div>
                <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="{{ asset('medilab/assets') }}/img/departments-1.jpg" alt="" class="img-fluid">
                </div>
                </div>
            </div>
            <div class="tab-pane" id="tab-2">
                <div class="row gy-4">
                <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Et blanditiis nemo veritatis excepturi</h3>
                    <p class="fst-italic">Qui laudantium consequatur laborum sit qui ad sapiente dila parde sonata raqer a videna mareta paulona marka</p>
                    <p>Ea ipsum voluptatem consequatur quis est. Illum error ullam omnis quia et reiciendis sunt sunt est. Non aliquid repellendus itaque accusamus eius et velit ipsa voluptates. Optio nesciunt eaque beatae accusamus lerode pakto madirna desera vafle de nideran pal</p>
                </div>
                <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="{{ asset('medilab/assets') }}/img/departments-2.jpg" alt="" class="img-fluid">
                </div>
                </div>
            </div>
            <div class="tab-pane" id="tab-3">
                <div class="row gy-4">
                <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Impedit facilis occaecati odio neque aperiam sit</h3>
                    <p class="fst-italic">Eos voluptatibus quo. Odio similique illum id quidem non enim fuga. Qui natus non sunt dicta dolor et. In asperiores velit quaerat perferendis aut</p>
                    <p>Iure officiis odit rerum. Harum sequi eum illum corrupti culpa veritatis quisquam. Neque necessitatibus illo rerum eum ut. Commodi ipsam minima molestiae sed laboriosam a iste odio. Earum odit nesciunt fugiat sit ullam. Soluta et harum voluptatem optio quae</p>
                </div>
                <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="{{ asset('medilab/assets') }}/img/departments-3.jpg" alt="" class="img-fluid">
                </div>
                </div>
            </div>
            <div class="tab-pane" id="tab-4">
                <div class="row gy-4">
                <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Fuga dolores inventore laboriosam ut est accusamus laboriosam dolore</h3>
                    <p class="fst-italic">Totam aperiam accusamus. Repellat consequuntur iure voluptas iure porro quis delectus</p>
                    <p>Eaque consequuntur consequuntur libero expedita in voluptas. Nostrum ipsam necessitatibus aliquam fugiat debitis quis velit. Eum ex maxime error in consequatur corporis atque. Eligendi asperiores sed qui veritatis aperiam quia a laborum inventore</p>
                </div>
                <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="{{ asset('medilab/assets') }}/img/departments-4.jpg" alt="" class="img-fluid">
                </div>
                </div>
            </div>
            <div class="tab-pane" id="tab-5">
                <div class="row gy-4">
                <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Est eveniet ipsam sindera pad rone matrelat sando reda</h3>
                    <p class="fst-italic">Omnis blanditiis saepe eos autem qui sunt debitis porro quia.</p>
                    <p>Exercitationem nostrum omnis. Ut reiciendis repudiandae minus. Omnis recusandae ut non quam ut quod eius qui. Ipsum quia odit vero atque qui quibusdam amet. Occaecati sed est sint aut vitae molestiae voluptate vel</p>
                </div>
                <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="{{ asset('medilab/assets') }}/img/departments-5.jpg" alt="" class="img-fluid">
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section><!-- End Departments Section --> --}}
    <!-- ======= Doctors Section ======= -->
    <section id="doctors" class="doctors">
        <x-home-kaprodi :prodi='$prodi' />
    </section>
    <!-- End Doctors Section -->
    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
        <x-home-pertanyaan-umum />
    </section>
    <!-- End Frequently Asked Questions Section -->
    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
        <x-home-respon-alumni />
    </section>
    <!-- End Testimonials Section -->
    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
    <x-home-gallery />
    </section>
    <!-- End Gallery Section -->
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
        <x-home-lokasi />
    </section>
    <!-- End Contact Section -->

@endsection

@push('footer')
    <x-home-footer />
@endpush
