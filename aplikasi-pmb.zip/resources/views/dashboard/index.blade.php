@extends('layouts.admin-layout')

@section('title', 'Dashboard')

@section('content-header', 'Index Page')

@section('content-body')
    {{-- <livewire:dashboard-index /> --}}
@endsection
