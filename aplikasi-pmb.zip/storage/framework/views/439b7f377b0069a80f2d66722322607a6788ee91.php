<div>

    <?php $__env->startSection('css'); ?>
    <style>
        .modal-backdrop.show {
            display: none !important;
        }

        table.dataTable tbody td {
            padding: 8px 2px!important;
        }

        table.dataTable {
            border-color: black!important;
        }

        .modal-title {
            font-size: 20px!important;
        }

        .fix-text {
            color: black!important;
        }

        .cke {
            visibility: visible !important;
        }

        table.dataTable tbody th,
        table.dataTable tbody td {
            padding: 8px 10px!important;
            border-color: #d8d8d8!important;
            border-top-color: #d8d8d8!important;
            border-right-color: #d8d8d8!important;
            border-bottom-color: #d8d8d8!important;
            border-left-color: #d8d8d8!important;
            table-layout:fixed!important;
            white-space: nowrap!important;
        }

        .button-text-fix {
            font-size: 11px!important;
        }

        table.dataTable {
            color: rgb(0, 0, 0)!important;
        }
    </style>
    <?php $__env->stopSection(); ?>
    <section class="section">

        <div class="section-header">
            <div class="container">
                <div class="row my-1">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4 class="text-dark mb-0"><?php echo e($contentheader); ?></h4>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                        <button class="btn btn-md btn-info d-flex justify-content-end" data-toggle="modal" data-target="#modaltambahinformasi">Tambah Informasi</button>
                    </div>
                </div>
                
                <div class="modal fade" id="modaltambahinformasi" tabindex="1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Tambah Informasi</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">Tambah informasi Baru</div>
                            
                                
                                <div class="modal-footer">
                                    <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-outline-danger" >
                                        Tambah
                                    </button>
                                </div>
                            

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="section-body">
            <div class="card">
                <div class="card-body">

                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <table id="example1" class="table table-bordered border-1" style="width:100%">
                            <thead class="thead-dark">
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Kode Informasi</th>
                                    <th>Title</th>
                                    <th>Kelola</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->informasi_kode); ?></td>
                                        <td><?php echo e(Str::limit($item->informasi_title, 20)); ?></td>
                                        <td>
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 d-flex mx-auto justify-content-center">

                                                    <a class="btn btn-sm btn-info mr-1 rounded" href="#" data-toggle="modal" data-target="#modallihat<?php echo e($item->id); ?>">
                                                        <i class="fas fa-info-circle"></i>
                                                        Lihat
                                                    </a>

                                                    

                                                    <a href="#" class="btn btn-danger rounded btn-sm mr-2" data-toggle="modal" data-target="#modaldelete<?php echo e($item->id); ?>">
                                                        <i class="fas fa-trash"></i>
                                                        Hapus
                                                    </a>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>

                                    
                                    <div class="modal fade" id="modaldelete<?php echo e($item->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h4 class="modal-title">Konfirmasi Tindakan</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">Apakah anda yakin ingin menghapus item ini? </div>
                                                
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                                        <button wire:click="$emitSelf('hapus', <?php echo e($item->id); ?>)" class="btn btn-outline-danger" >
                                                            Delete
                                                        </button>
                                                        
                                                    </div>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="modal fade" id="modallihat<?php echo e($item->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h4 class="modal-title fix-text">Data Mahasiswa <?php echo e($item->data_nama_lengkap); ?></h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-sm-12 col-md-12 col-lg-12">
                                                                <p class="fix-text">
                                                                    <b> Kode : </b> <?php echo e($item->informasi_kode); ?> <br>
                                                                    <br>
                                                                    <b> Title : </b> <br>
                                                                    <?php echo e($item->informasi_title); ?> <br>
                                                                    <br />
                                                                    <b> Body : </b> <br>
                                                                    <p class="text-justify">
                                                                        <?php echo $item->informasi_body; ?>

                                                                    </p>
                                                                    <br />
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Tutup</button>
                                                        
                                                    </div>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </section>

    <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function() {
                $('#example1').DataTable();
            });
        </script>
    <?php $__env->stopSection(); ?>

</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/livewire/dashboard-data-informasi.blade.php ENDPATH**/ ?>