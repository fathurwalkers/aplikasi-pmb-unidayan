<div>

    <?php $__env->startPush('css'); ?>
        <style>
            .isDisabled {
                cursor: not-allowed;
                opacity: 0.5;
            }
            .isDisabled > a {
                color: currentColor;
                display: inline-block;  /* For IE11/ MS Edge bug */
                pointer-events: none;
                text-decoration: none;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <ul class="sidebar-menu">
        <li class="menu-header">Menus</li>
        <li class="nav-item dropdown">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li><a class="nav-link" href="#" data-toggle="modal" data-target="#modallihatprofile<?php echo e($usersss->id); ?>">Profil Pengguna</a></li>
            </ul>
        </li>
        <li class="menu-header">Pengelolaan</li>
        <li class="nav-item dropdown">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Pendaftaran</span></a>
            <ul class="dropdown-menu">
                <?php if($usersss->login_status == "verified"): ?>
                    <li><a class="nav-link" href="<?php echo e(route('data-mahasiswa')); ?>">Data Mahasiswa</a></li>
                    <li><a class="nav-link" href="<?php echo e(route('data-akun-mahasiswa')); ?>">Data Akun Mahasiswa</a></li>
                    
                <?php endif; ?>
                <?php if($usersss->login_status == "unverified"): ?>
                    <li><a class="nav-link disabled" href="#">Data Mahasiswa</a></li>
                    <li><a class="nav-link disabled" href="#">Data Akun Mahasiswa</a></li>
                    
                <?php endif; ?>
            </ul>
        </li>
        <li class="nav-item dropdown">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Informasi</span></a>
            <ul class="dropdown-menu">
                <?php if($usersss->login_status == "verified"): ?>
                    <li><a class="nav-link" href="#">Daftar Informasi</a></li>
                    
                <?php endif; ?>
                <?php if($usersss->login_status == "unverified"): ?>
                    <li><a class="nav-link disabled" href="#">Daftar Informasi</a></li>
                    
                <?php endif; ?>
            </ul>
        </li>
        
    </ul>

    
    <div class="modal fade" id="modallihatprofile<?php echo e($usersss->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title fix-text">Profile Pengguna : <?php echo e($usersss->login_nama); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <p class="fix-text">
                                    <b> Informasi Akun </b> <br>
                                    Nama Lengkap <br>
                                    Username <br>
                                    Email <br>
                                    Telepon <br>
                                    Status <br>
                                </p>
                            </div>
                            <div class="col-sm-8 col-md-8 col-lg-8">
                                <p class="fix-text">
                                    <br />
                                    : <?php echo e($usersss->login_nama); ?><br>
                                    : <?php echo e($usersss->login_username); ?><br>
                                    : <?php echo e($usersss->login_email); ?><br>
                                    : <?php echo e($usersss->login_telepon); ?><br>
                                    : <?php echo e($usersss->login_status); ?><br>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                    
                    <div class="modal-footer">
                        <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Tutup</button>
                        
                    </div>
                

            </div>
        </div>
    </div>
    

</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/livewire/dashboard-navbar.blade.php ENDPATH**/ ?>