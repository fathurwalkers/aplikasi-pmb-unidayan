<div>

    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 footer-contact">
                <h3>UNIDAYAN INFO</h3>
                <p>
                    Jl. Yos Sudarso No.43<br>
                    Wale, Kec. Wolio, Kota Bau-Bau, Sulawesi Tenggara <br />
                    Kode Pos : 93711<br><br>
                    <strong>Phone:</strong> 04022821327<br>
                    <strong>Email:</strong> pmb@unidayan.ac.id<br>
                </p>
                </div>

                <div class="col-lg-6 col-md-6 footer-newsletter">
                <h4>Bergabung untuk dapat Info dari Kami</h4>
                <p>Daftarkan dan Subscribe Email anda untuk mendapatkan informasi terupdate dari kami</p>
                <form action="" method="post">
                    <input type="email" name="email"><input type="submit" value="Subscribe">
                </form>
                </div>

            </div>
        </div>
    </div>

    <div class="container d-md-flex py-4">

        <div class="me-md-auto text-center text-md-start">
            <div class="copyright">
            &copy; Copyright <strong><span>Unidayan Info</span></strong>. All Rights Reserved
            </div>
            <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/ -->
            Designed by <a href="https://bootstrapmade.com/">Techno Buton Raya</a>
            </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
            <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
            <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/components/home-footer.blade.php ENDPATH**/ ?>