<?php $__env->startSection('title', 'Halaman Pendaftaran'); ?>

<?php $__env->startSection('header-content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center">
        <div class="container">
        <h1>Website Pendaftaraan Mahasiswa Baru</h1>
        <h2>Universitas Dayanu Ikhsanuddin</h2>
        
        </div>
    </section>
    <!-- End Hero -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>
    <section id="counts" class="counts">

        <div class="container">
            <div class="row">
                <div class="card py-2">
                    <div class="card-body">

                        <div class="container my-4">

                            <form action="<?php echo e(route('post-pendaftaran')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_foto">Pas Foto 3x4 (Format: .jpg, .jpeg / Maks: 2MB)
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="file" class="form-control <?php $__errorArgs = ['data_foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_foto" aria-describedby="emailHelp" placeholder="" name="data_foto">
                                            <?php $__errorArgs = ['data_foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_kampus_pilihan">Kampus Pilihan
                                                <span style="color:red;">*</span>
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['data_kampus_pilihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_kampus_pilihan" name="data_kampus_pilihan">
                                                <option selected value="">Pilih Kampus Pilihan</option>
                                                <option value="KAMPUS PASARWAJO">Kampus Pasarwajo</option>
                                                <option value="KAMPUS PALAGIMATA">Kampus Palagimata</option>
                                            </select>
                                            <?php $__errorArgs = ['data_kampus_pilihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;">Kampus pilihan harus dipilih.</span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_nama_lengkap">Nama Lengkap
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['data_nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_nama_lengkap" aria-describedby="emailHelp" placeholder="" name="data_nama_lengkap" value="<?php echo e(old('data_nama_lengkap')); ?>">
                                            <?php $__errorArgs = ['data_nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Email
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="email" class="form-control <?php $__errorArgs = ['data_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="data_email" value="<?php echo e(old('data_email')); ?>">
                                            <?php $__errorArgs = ['data_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_telepon">Nomor Telepon / HP
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="number" class="form-control <?php $__errorArgs = ['data_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_telepon" aria-describedby="emailHelp" placeholder="" name="data_telepon" value="<?php echo e(old('data_telepon')); ?>">
                                            <?php $__errorArgs = ['data_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_jenis_kelamin">Jenis Kelamin
                                                <span style="color:red;">*</span>
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['data_jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_jenis_kelamin" name="data_jenis_kelamin">
                                                <option selected value="">Pilih jenis kelamin</option>
                                                <option value="L">Laki-Laki</option>
                                                <option value="P">Perempuan</option>
                                            </select>
                                            <?php $__errorArgs = ['data_jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;">Jenis Kelamin harus dipilih.</span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_tempat_lahir">Tempat Lahir
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['data_tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_tempat_lahir" aria-describedby="emailHelp" placeholder="" name="data_tempat_lahir" value="<?php echo e(old('data_tempat_lahir')); ?>">
                                            <?php $__errorArgs = ['data_tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_tanggal_lahir">Tanggal Lahir
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="date" class="form-control <?php $__errorArgs = ['data_tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_tanggal_lahir" aria-describedby="emailHelp" placeholder="" name="data_tanggal_lahir" value="<?php echo e(old('data_tanggal_lahir')); ?>">
                                            <?php $__errorArgs = ['data_tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_nama_ibu_kandung">Nama Gadis Ibu Kandung
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['data_nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_nama_ibu_kandung" aria-describedby="emailHelp" placeholder="" name="data_nama_ibu_kandung" value="<?php echo e(old('data_nama_ibu_kandung')); ?>">
                                            <?php $__errorArgs = ['data_nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_asal_sekolah">Asal Sekolah
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['data_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_asal_sekolah" aria-describedby="emailHelp" placeholder="" name="data_asal_sekolah" value="<?php echo e(old('data_asal_sekolah')); ?>">
                                            <?php $__errorArgs = ['data_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="data_tahun_lulus">Tahun Lulus
                                                <span style="color:red;">*</span>
                                            </label>
                                            <input type="number" class="form-control <?php $__errorArgs = ['data_tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_tahun_lulus" aria-describedby="emailHelp" placeholder="" name="data_tahun_lulus" value="<?php echo e(old('data_tahun_lulus')); ?>">
                                            <?php $__errorArgs = ['data_tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;"><?php echo e($message); ?></span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_pilihan_jurusan1">Pilihan Program Studi Pertama (Pilihan Utama)
                                                <span style="color:red;">*</span>
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['data_pilihan_jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_pilihan_jurusan1" name="data_pilihan_jurusan1">
                                                <option selected value="">-- Pilihan Program Studi Pertama --</option>
                                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($prodi_item->id); ?>"><?php echo e($prodi_item->prodi_nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['data_pilihan_jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;">Pilihan jurusan pertama harus dipilih.</span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_pilihan_jurusan2">Pilihan Program Studi Kedua (Alternatif)
                                                <span style="color:red;">*</span>
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['data_pilihan_jurusan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_pilihan_jurusan2" name="data_pilihan_jurusan2">
                                                <option selected value="">-- Pilihan Program Studi Kedua --</option>
                                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($prodi_item->id); ?>"><?php echo e($prodi_item->prodi_nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['data_pilihan_jurusan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;">Pilihan jurusan kedua harus dipilih.</span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="data_pilihan_jurusan3">Pilihan Program Studi Ketiga (Alternatif)
                                                <span style="color:red;">*</span>
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['data_pilihan_jurusan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_pilihan_jurusan3" name="data_pilihan_jurusan3">
                                                <option selected value="">-- Pilihan Program Studi Ketiga --</option>
                                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($prodi_item->id); ?>"><?php echo e($prodi_item->prodi_nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['data_pilihan_jurusan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="emailHelp" class="form-text text-muted"><span style="color:red;">Pilihan jurusan ketiga harus dipilih.</span></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4 mx-auto d-flex justify-content-center">
                                    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto d-flex justify-content-center">
                                        <div class="form-group mx-auto d-flex justify-content-center">
                                            <input type="checkbox" name="chekboxxx" onchange="document.getElementById('calculatebutton').disabled = !this.checked;" /> &nbsp; Saya menyetujui syarat diatas
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4 mx-auto d-flex justify-content-center">
                                    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto d-flex justify-content-center">
                                        <div class="form-group mx-auto d-flex justify-content-center">
                                            <button class="btn btn-md btn-primary" type="submit" id="calculatebutton" disabled>DAFTAR SEKARANG</button>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3 mx-auto d-flex justify-content-center">
                                    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto d-flex justify-content-center">
                                        <div class="form-group mx-auto d-flex justify-content-center">
                                            <small id="emailHelp" class="form-text text-muted">Silahkan klik tombol "DAFTAR SEKARANG" untuk melanjutkan proses pendaftaran.</small>
                                        </div>
                                    </div>
                                </div>

                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    // $( document ).ready(function() {
    //     document.getElementById("calculatebutton").disabled = true;
    //     function goFurther(elem) {
    //         if (elem.checked == true)  {
    //             document.getElementById("calculatebutton").disabled = false;
    //         } else {
    //             document.getElementById("calculatebutton").disabled = true;
    //         }
    //     }
    // });

    // document.getElementById("calculatebutton").disabled = true;
    // function goFurther(elem) {
    //     if (elem.checked == true)
    //         document.getElementById("calculatebutton").disabled = false;
    //     else
    //         document.getElementById("calculatebutton").disabled = true;
    //     }
    // }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/home/pendaftaran.blade.php ENDPATH**/ ?>