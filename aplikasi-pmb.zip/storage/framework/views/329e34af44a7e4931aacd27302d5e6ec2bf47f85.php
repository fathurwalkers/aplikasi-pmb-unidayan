<div>
    <?php $__env->startPush('css'); ?>
    <style>
        /* .doctors .member {
            position: relative;
            box-shadow: 0px 2px 15px rgb(44 73 100 / 8%);
            padding: 15px!important;
            border-radius: 10px;
        } */
        .doctors .member .pic {
            overflow: hidden;
            width: 200px!important;
            border-radius: 80%!important;
            height: 200px!important;
        }

        .img-fix {
            width: 100%!important;
            height: 100%!important;
        }
    </style>
    <?php $__env->stopPush(); ?>
    <div class="container">

        <div class="section-title">
          <h2>Ketua Program Studi</h2>
          <p>
              Daftar masing-masing ketua Program Studi pada Universitas Dayanu Ikhsanuddin
          </p>
        </div>

        <div class="row">

            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="member d-flex align-items-start">
                    <div class="pic"><img src="<?php echo e(asset('default-img')); ?>/<?php echo e($item->prodi_foto_pimpinan); ?>" class="img-fluid img-fix" alt="" width="440px" height="440px"></div>
                    <div class="member-info">
                        <h4><?php echo e($item->prodi_nama_pimpinan); ?></h4>
                        <span>Ketua Program Studi <?php echo e($item->prodi_nama); ?></span>
                        
                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

      </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/components/home-kaprodi.blade.php ENDPATH**/ ?>