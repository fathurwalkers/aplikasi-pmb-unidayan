<div>
    <div class="container">

        <div class="section-title">
          <h2>Peta Lokasi</h2>
          <p>
              Berikut lokasi Peta Lokasi yang menunjukkan posisi lokasi Universitas Dayanu Ikhsanuddin
          </p>
        </div>
      </div>

      <div>
          <div class="row">
              <div class="col-sm-2 col-md-2 col-lg-2">
              </div>
              <div class="col-sm-8 col-md-8 col-lg-8">
                  <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3971.5199347354983!2d122.57049651476551!3d-5.489509996019269!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2da47694c3c936c3%3A0x7b50a493452ef15!2sUniversity%20Dayanu%20Ikhsanuddin!5e0!3m2!1sen!2sid!4v1650647218621!5m2!1sen!2sid" frameborder="0" allowfullscreen></iframe>
                  
              </div>
              <div class="col-sm-2 col-md-2 col-lg-2">
              </div>
          </div>
      </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/components/home-lokasi.blade.php ENDPATH**/ ?>