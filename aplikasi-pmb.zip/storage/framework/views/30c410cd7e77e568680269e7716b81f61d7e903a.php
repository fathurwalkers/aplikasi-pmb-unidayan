<div>

    <section class="section">
        <div class="section-header">
          <h1><?php echo e($contentheader); ?></h1>
        </div>

        <div class="section-body">
            <div class="card">
                <div class="card-body">
                    <h1>Index Page</h1>
                </div>
            </div>
        </div>
    </section>

</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/livewire/dashboard-index.blade.php ENDPATH**/ ?>