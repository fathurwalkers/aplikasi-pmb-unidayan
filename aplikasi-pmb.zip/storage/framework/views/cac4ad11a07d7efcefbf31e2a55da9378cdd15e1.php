<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <!-- CSS Libraries -->

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('stisla/assets')); ?>/css/style.css">
  <link rel="stylesheet" href="<?php echo e(asset('stisla/assets')); ?>/css/components.css">
  <link rel="stylesheet" href="<?php echo e(asset('datatables')); ?>/datatables.min.css">
  <style>
    .modal-backdrop.show {
        display: none !important;
    }
  </style>
    <?php echo $__env->yieldContent('css'); ?>
  <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
  <div id="app">
    <div class="main-wrapper">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-search-panel', [])->html();
} elseif ($_instance->childHasBeenRendered('H4Lr88r')) {
    $componentId = $_instance->getRenderedChildComponentId('H4Lr88r');
    $componentTag = $_instance->getRenderedChildComponentTagName('H4Lr88r');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H4Lr88r');
} else {
    $response = \Livewire\Livewire::mount('dashboard-search-panel', []);
    $html = $response->html();
    $_instance->logRenderedChild('H4Lr88r', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <ul class="navbar-nav navbar-right ml-auto">

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-laporan', [])->html();
} elseif ($_instance->childHasBeenRendered('31fXeek')) {
    $componentId = $_instance->getRenderedChildComponentId('31fXeek');
    $componentTag = $_instance->getRenderedChildComponentTagName('31fXeek');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('31fXeek');
} else {
    $response = \Livewire\Livewire::mount('dashboard-laporan', []);
    $html = $response->html();
    $_instance->logRenderedChild('31fXeek', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-notifikasi', [])->html();
} elseif ($_instance->childHasBeenRendered('Zqek0Az')) {
    $componentId = $_instance->getRenderedChildComponentId('Zqek0Az');
    $componentTag = $_instance->getRenderedChildComponentTagName('Zqek0Az');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Zqek0Az');
} else {
    $response = \Livewire\Livewire::mount('dashboard-notifikasi', []);
    $html = $response->html();
    $_instance->logRenderedChild('Zqek0Az', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-user-panel', [])->html();
} elseif ($_instance->childHasBeenRendered('GV6vVSO')) {
    $componentId = $_instance->getRenderedChildComponentId('GV6vVSO');
    $componentTag = $_instance->getRenderedChildComponentTagName('GV6vVSO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GV6vVSO');
} else {
    $response = \Livewire\Livewire::mount('dashboard-user-panel', []);
    $html = $response->html();
    $_instance->logRenderedChild('GV6vVSO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </ul>
      </nav>
        <div class="main-sidebar">
            <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                <a href="index.html">Stisla</a>
            </div>
            <div class="sidebar-brand sidebar-brand-sm">
                <a href="index.html">St</a>
            </div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-navbar', [])->html();
} elseif ($_instance->childHasBeenRendered('fzW3Kzl')) {
    $componentId = $_instance->getRenderedChildComponentId('fzW3Kzl');
    $componentTag = $_instance->getRenderedChildComponentTagName('fzW3Kzl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fzW3Kzl');
} else {
    $response = \Livewire\Livewire::mount('dashboard-navbar', []);
    $html = $response->html();
    $_instance->logRenderedChild('fzW3Kzl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg btn-block btn-icon-split">
                        <i class="fas fa-rocket"></i> Halaman Utama
                    </a>
                </div>
            </aside>
        </div>

      <!-- Main Content -->
      <div class="main-content">
        <?php echo $__env->yieldContent('main-content'); ?>
      </div>

      
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/stisla.js"></script>

  <!-- JS Libraies -->

  <!-- Template JS File -->
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/scripts.js"></script>
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/custom.js"></script>
  <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
  <?php echo $__env->yieldContent('js'); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>

  <!-- Page Specific JS File -->
</body>
</html>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/layouts/admin-layout.blade.php ENDPATH**/ ?>