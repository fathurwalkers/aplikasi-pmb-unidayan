<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <!-- CSS Libraries -->

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('stisla/assets')); ?>/css/style.css">
  <link rel="stylesheet" href="<?php echo e(asset('stisla/assets')); ?>/css/components.css">
  <link rel="stylesheet" href="<?php echo e(asset('datatables')); ?>/datatables.min.css">
    <?php echo $__env->yieldContent('css'); ?>
  <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
  <div id="app">
    <div class="main-wrapper">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-search-panel', [])->html();
} elseif ($_instance->childHasBeenRendered('qdFT1vh')) {
    $componentId = $_instance->getRenderedChildComponentId('qdFT1vh');
    $componentTag = $_instance->getRenderedChildComponentTagName('qdFT1vh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qdFT1vh');
} else {
    $response = \Livewire\Livewire::mount('dashboard-search-panel', []);
    $html = $response->html();
    $_instance->logRenderedChild('qdFT1vh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <ul class="navbar-nav navbar-right ml-auto">

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-laporan', [])->html();
} elseif ($_instance->childHasBeenRendered('R9JMTcX')) {
    $componentId = $_instance->getRenderedChildComponentId('R9JMTcX');
    $componentTag = $_instance->getRenderedChildComponentTagName('R9JMTcX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R9JMTcX');
} else {
    $response = \Livewire\Livewire::mount('dashboard-laporan', []);
    $html = $response->html();
    $_instance->logRenderedChild('R9JMTcX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-notifikasi', [])->html();
} elseif ($_instance->childHasBeenRendered('Tnd8ivl')) {
    $componentId = $_instance->getRenderedChildComponentId('Tnd8ivl');
    $componentTag = $_instance->getRenderedChildComponentTagName('Tnd8ivl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Tnd8ivl');
} else {
    $response = \Livewire\Livewire::mount('dashboard-notifikasi', []);
    $html = $response->html();
    $_instance->logRenderedChild('Tnd8ivl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-user-panel', [])->html();
} elseif ($_instance->childHasBeenRendered('4wCE5SS')) {
    $componentId = $_instance->getRenderedChildComponentId('4wCE5SS');
    $componentTag = $_instance->getRenderedChildComponentTagName('4wCE5SS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4wCE5SS');
} else {
    $response = \Livewire\Livewire::mount('dashboard-user-panel', []);
    $html = $response->html();
    $_instance->logRenderedChild('4wCE5SS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </ul>
      </nav>
        <div class="main-sidebar">
            <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                <a href="index.html">Stisla</a>
            </div>
            <div class="sidebar-brand sidebar-brand-sm">
                <a href="index.html">St</a>
            </div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-navbar', [])->html();
} elseif ($_instance->childHasBeenRendered('x8GF8gz')) {
    $componentId = $_instance->getRenderedChildComponentId('x8GF8gz');
    $componentTag = $_instance->getRenderedChildComponentTagName('x8GF8gz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('x8GF8gz');
} else {
    $response = \Livewire\Livewire::mount('dashboard-navbar', []);
    $html = $response->html();
    $_instance->logRenderedChild('x8GF8gz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg btn-block btn-icon-split">
                        <i class="fas fa-rocket"></i> Halaman Utama
                    </a>
                </div>
            </aside>
        </div>

      <!-- Main Content -->
      <div class="main-content">
        <?php echo $__env->yieldContent('main-content'); ?>
      </div>

      
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/stisla.js"></script>

  <!-- JS Libraies -->

  <!-- Template JS File -->
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/scripts.js"></script>
  <script src="<?php echo e(asset('stisla/assets')); ?>/js/custom.js"></script>
  <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
  <?php echo $__env->yieldContent('js'); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>

  <!-- Page Specific JS File -->
</body>
</html>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/layouts/admin-layout.blade.php ENDPATH**/ ?>