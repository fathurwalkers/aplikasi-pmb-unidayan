<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content-header', 'Index Page'); ?>

<?php $__env->startSection('content-body'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/dashboard/index.blade.php ENDPATH**/ ?>