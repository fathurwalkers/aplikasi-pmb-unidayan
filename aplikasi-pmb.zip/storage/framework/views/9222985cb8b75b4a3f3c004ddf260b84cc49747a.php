<div>
    <div class="container">

        <div class="section-title">
          <h2>Gallery</h2>
          <p>Berikut Gambaran sekitaran Kampus Universitas Dayanu Ikhsanuddin</p>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row g-0">

            <?php for($i = 1; $i < 9; $i++): ?>
                <div class="col-lg-3 col-md-4">
                    <div class="gallery-item">
                    <a href="<?php echo e(asset('default-img')); ?>/foto-kampus<?php echo e($i); ?>.jpg" class="galelry-lightbox">
                        <img src="<?php echo e(asset('default-img')); ?>/foto-kampus<?php echo e($i); ?>.jpg" alt="" class="img-fluid fixedimg">
                    </a>
                    </div>
                </div>
            <?php endfor; ?>

        </div>

      </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/components/home-gallery.blade.php ENDPATH**/ ?>