<div>
    <div class="container">

        <div class="section-title">
          <h2>Fakultas</h2>
          <p>Universitas Dayanu Ikhsanuddin terdiri dari berbagai macam pilihan Fakultas yang semua nya telah terakreditasi dengan baik.</p>
        </div>

        <div class="row">

            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-3 d-flex align-items-stretch mt-4">
                <div class="icon-box">
                <div class="icon"><i class="fas fa-heartbeat"></i></div>
                <h4><a href=""><?php echo e($item->prodi_nama); ?></a></h4>
                <p>Voluptatum deleniti atque corrupti quos dolores et quas molestiasddddddddddddddddddddddddddddddddddddddddddd excepturi</p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

        </div>

      </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/components/home-fakultas.blade.php ENDPATH**/ ?>