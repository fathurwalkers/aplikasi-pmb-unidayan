<div>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable();
        });
    </script>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/livewire/js-script.blade.php ENDPATH**/ ?>