<div>

    <?php $__env->startSection('css'); ?>
    <style>
        .modal-backdrop.show {
            display: none !important;
        }

        table.dataTable tbody td {
            padding: 8px 2px!important;
        }

        table.dataTable {
            border-color: black!important;
        }

        .modal-title {
            font-size: 20px!important;
        }

        .fix-text {
            color: black!important;
        }
    </style>
    <?php $__env->stopSection(); ?>
    <section class="section">

        <div class="section-header">
          <h4 class="text-dark pl-2 mb-0"><?php echo e($contentheader); ?></h4>
        </div>
        <div class="section-body">
            <div class="card">
                <div class="card-body">

                    <div class="container">
                        <table id="example1" class="table table-bordered border-1" style="width:100%">
                            <thead class="thead-dark">
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Pendaftaran</th>
                                    <th>Pembayaran</th>
                                    
                                    <th>Kelola</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(Str::limit($item->data_nama_lengkap, 15)); ?></td>
                                        <td><?php echo e($item->data_email); ?></td>
                                        <td class="text-center" style="width: 10% !important;"><?php echo e($item->data_jenis_kelamin); ?></td>
                                        <td>
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                    <?php switch($item->data_status_pendaftaran):
                                                        case ("BELUM DISETUJUI"): ?>
                                                            <button class="btn btn-sm btn-danger">
                                                                <?php echo e($item->data_status_pendaftaran); ?>

                                                            </button>
                                                            <?php break; ?>
                                                        <?php case ("DISETUJUI"): ?>
                                                            <button class="btn btn-sm btn-success">
                                                                <?php echo e($item->data_status_pendaftaran); ?>

                                                            </button>
                                                            <?php break; ?>
                                                    <?php endswitch; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                    <?php switch($item->data_status_pembayaran):
                                                        case ("DIPROSES"): ?>
                                                            <button class="btn btn-sm btn-info">
                                                                <?php echo e($item->data_status_pembayaran); ?>

                                                            </button>
                                                            <?php break; ?>
                                                        <?php case ("SELESAI"): ?>
                                                            <button class="btn btn-sm btn-success">
                                                                <?php echo e($item->data_status_pembayaran); ?>

                                                            </button>
                                                            <?php break; ?>
                                                        <?php case ("DIBATALKAN"): ?>
                                                            <button class="btn btn-sm btn-danger">
                                                                <?php echo e($item->data_status_pembayaran); ?>

                                                            </button>
                                                            <?php break; ?>
                                                    <?php endswitch; ?>
                                                </div>
                                            </div>
                                        </td>

                                        

                                        <td>
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 d-flex mx-auto justify-content-center">

                                                    <a class="btn btn-sm btn-info mr-1 rounded" href="#" data-toggle="modal" data-target="#modallihat<?php echo e($item->id); ?>">
                                                        <i class="fas fa-info-circle"></i>
                                                        Lihat
                                                    </a>

                                                    

                                                    <a href="#" class="btn btn-danger rounded btn-sm mr-2" data-toggle="modal" data-target="#modaldelete<?php echo e($item->id); ?>">
                                                        <i class="fas fa-trash"></i>
                                                        Hapus
                                                    </a>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>

                                    
                                    <div class="modal fade" id="modaldelete<?php echo e($item->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h4 class="modal-title">Konfirmasi Tindakan</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">Apakah anda yakin ingin menghapus item ini? </div>
                                                
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                                        <button wire:click="$emitSelf('hapus', <?php echo e($item->id); ?>)" class="btn btn-outline-danger" >
                                                            Delete
                                                        </button>
                                                        
                                                    </div>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="modal fade" id="modallihat<?php echo e($item->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h4 class="modal-title fix-text">Data Mahasiswa <?php echo e($item->data_nama_lengkap); ?></h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-sm-4 col-md-4 col-lg-4">
                                                                <p class="fix-text">
                                                                    <b> Data Diri </b> <br>
                                                                    Nama Lengkap <br>
                                                                    Jenis Kelamin <br>
                                                                    Email <br>
                                                                    No. HP / Telepon <br>
                                                                    Tempat Lahir <br>
                                                                    Tanggal Lahir <br>
                                                                    <br />
                                                                    <b> Informasi Sekolah </b><br>
                                                                    Asal Sekolah <br>
                                                                    Tahun Lulus <br>
                                                                    <br />
                                                                    <b> Informasi Akun </b> <br>
                                                                    Username <br>
                                                                    Password <br>
                                                                </p>
                                                            </div>
                                                            <div class="col-sm-8 col-md-8 col-lg-8">
                                                                <p class="fix-text">
                                                                    <br />
                                                                    Nama Lengkap <br>
                                                                    Jenis Kelamin <br>
                                                                    Email <br>
                                                                    No. HP / Telepon <br>
                                                                    Tempat Lahir <br>
                                                                    Tanggal Lahir <br>
                                                                    <br />
                                                                    <br />
                                                                    Asal Sekolah <br>
                                                                    Tahun Lulus <br>
                                                                    <br />
                                                                    <br />
                                                                    Username <br>
                                                                    Password <br>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Tutup</button>
                                                        
                                                    </div>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </section>

    <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function() {
                $('#example1').DataTable();
            });
        </script>
    <?php $__env->stopSection(); ?>

</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pmb\resources\views/livewire/dashboard-data-mahasiswa.blade.php ENDPATH**/ ?>