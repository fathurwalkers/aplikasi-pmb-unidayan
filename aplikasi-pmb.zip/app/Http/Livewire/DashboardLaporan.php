<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DashboardLaporan extends Component
{
    public function render()
    {
        return view('livewire.dashboard-laporan');
    }
}
