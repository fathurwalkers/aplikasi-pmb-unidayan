<?php

namespace App\Http\Livewire;

use Livewire\Component;

class JsScript extends Component
{
    public function render()
    {
        return view('livewire.js-script')
        ->extends('layouts.admin-layout')
        ->section('js');
    }
}
