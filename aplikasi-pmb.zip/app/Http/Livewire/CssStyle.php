<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CssStyle extends Component
{
    public function render()
    {
        return view('livewire.css-style')
        ->extends('layouts.admin-layout')
        ->section('css');
    }
}
