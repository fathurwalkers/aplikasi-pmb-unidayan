<?php return array (
  'css-style' => 'App\\Http\\Livewire\\CssStyle',
  'dashboard-data-akun-mahasiswa' => 'App\\Http\\Livewire\\DashboardDataAkunMahasiswa',
  'dashboard-data-mahasiswa' => 'App\\Http\\Livewire\\DashboardDataMahasiswa',
  'dashboard-index' => 'App\\Http\\Livewire\\DashboardIndex',
  'dashboard-laporan' => 'App\\Http\\Livewire\\DashboardLaporan',
  'dashboard-navbar' => 'App\\Http\\Livewire\\DashboardNavbar',
  'dashboard-notifikasi' => 'App\\Http\\Livewire\\DashboardNotifikasi',
  'dashboard-profile' => 'App\\Http\\Livewire\\DashboardProfile',
  'dashboard-search-panel' => 'App\\Http\\Livewire\\DashboardSearchPanel',
  'dashboard-user-panel' => 'App\\Http\\Livewire\\DashboardUserPanel',
  'js-script' => 'App\\Http\\Livewire\\JsScript',
);